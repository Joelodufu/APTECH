{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "14341954",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "language_info": {
   "name": "python"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
